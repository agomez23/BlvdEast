jQuery(function() {
	//jQuery('#tabs-left').bind('tabsshow', fixMap);
});

function fixMap(event, ui)
{
	console.dir({event: event, ui: ui});
}